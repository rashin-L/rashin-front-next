// // import { useRef } from 'react'
// import { Provider } from 'react-redux'
// // import { makeStore } from '../lib/store'
// import { persistStore } from 'redux-persist'
// // import {store} from './index';
// import { store } from '@/store';

// persistStore(store);
// export default function ReduxProvider({ children }) {

//     return <Provider store={store}>{children}</Provider>
// }