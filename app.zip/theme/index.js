export { default as theme } from './theme';
